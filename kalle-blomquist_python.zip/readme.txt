Kalle Blomquist secret language works like this: 

Every consonant is doubled, and in the middle between the two consonants an "o" is inserted. 
In addition, there is always a space before it.

Music by Jan125